import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const Input = z.object({
  prompt: z.string().min(1).max(20000),
  mode: z.enum(["code", "mentor"]),
  order: z.array(z.enum(["claude", "gpt", "gemini"])).min(1).max(3),
  exhausted: z.array(z.enum(["claude", "gpt", "gemini"])).max(3),
});

const SYSTEM = {
  code: "Eres un asistente de generación de código. Respeta estrictamente el ROL, CONTEXTO, TAREA, RESTRICCIONES y FORMATO DE SALIDA del prompt. Responde en español.",
  mentor:
    "Eres un mentor docente de desarrollo de software. Analiza el prompt del estudiante según los cinco pilares (Rol, Contexto, Tarea, Restricciones, Formato). Da: 1) diagnóstico breve por pilar, 2) tres ajustes concretos, 3) una versión mejorada del prompt. Tono cercano, en español, máximo 350 palabras.",
};

export const generateWithEngines = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) => Input.parse(d))
  .handler(async ({ data }) => {
    const { callEngine, ENGINE_MODELS } = await import("@/server/engines");
    const route: { engine: string; status: "ok" | "skipped" | "error"; detail: string }[] = [];
    for (const id of data.order) {
      if (data.exhausted.includes(id)) {
        route.push({ engine: id, status: "skipped", detail: "cupo de tokens agotado" });
        continue;
      }
      try {
        const r = await callEngine(id, SYSTEM[data.mode], data.prompt);
        route.push({ engine: id, status: "ok", detail: `${r.input} entrada + ${r.output} salida` });
        return { ok: true as const, engine: id, model: ENGINE_MODELS[id], text: r.text, input: r.input, output: r.output, route };
      } catch (e) {
        route.push({ engine: id, status: "error", detail: e instanceof Error ? e.message.slice(0, 140) : "error" });
      }
    }
    return { ok: false as const, route, error: "Ningún motor disponible: todos sin cupo o con error." };
  });
