// Motor de reglas PEIP: estructuración determinista en cinco pilares.
export type EngineId = "claude" | "gpt" | "gemini";
export type RoleId = "auto" | "profesor" | "revisor" | "arquitecto";

export const LANGS: Record<string, { n: string; re: RegExp; test: string; doc: string }> = {
  python: { n: "Python", re: /\bpython\b/i, test: "pytest", doc: "docstrings" },
  javascript: { n: "JavaScript", re: /\bjavascript\b|\bnode(\.?js)?\b|\bjs\b/i, test: "Jest", doc: "JSDoc" },
  typescript: { n: "TypeScript", re: /\btypescript\b|\bts\b/i, test: "Vitest", doc: "TSDoc" },
  java: { n: "Java", re: /\bjava\b(?!\s*script)/i, test: "JUnit 5", doc: "Javadoc" },
  csharp: { n: "C#", re: /c#|\.net\b|\bcsharp\b/i, test: "xUnit", doc: "comentarios XML" },
  php: { n: "PHP", re: /\bphp\b/i, test: "PHPUnit", doc: "PHPDoc" },
  sql: { n: "SQL", re: /\bsql\b|\bmysql\b|\bpostgres(ql)?\b/i, test: "consultas de verificación", doc: "comentarios" },
};

type Domain = "backend" | "frontend" | "datos" | "scripting" | "pruebas";
const DEFAULT_LANG: Record<Domain, string> = { backend: "python", frontend: "typescript", datos: "sql", scripting: "python", pruebas: "python" };
const DOMAINS: Record<Domain, { kw: RegExp; rol: (l: string) => string; ctx: string; rest: string[] }> = {
  backend: { kw: /api|endpoint|servidor|backend|autentic|contraseñ|login|token|funci[oó]n|validar|servicio/gi, rol: (l) => `Senior Backend Engineer especializado en ciberseguridad con ${l}`, ctx: "Módulo de un servicio backend / API web", rest: ["Validar y sanear todas las entradas externas.", "Separar la lógica de negocio de la capa de transporte."] },
  frontend: { kw: /componente|interfaz|formulario|bot[oó]n|react|html|css|p[aá]gina|pantalla|vista/gi, rol: (l) => `Senior Frontend Engineer especializado en accesibilidad con ${l}`, ctx: "Componente de interfaz de una aplicación web moderna", rest: ["Escapar todo contenido dinámico para evitar XSS.", "Cumplir criterios básicos de accesibilidad (etiquetas, foco, contraste)."] },
  datos: { kw: /sql|base de datos|consulta|tabla|dataframe|pandas|csv|etl|datos|dataset|query/gi, rol: (l) => `Ingeniero de datos senior especializado en ${l}`, ctx: "Capa de acceso y transformación de datos", rest: ["Usar consultas parametrizadas; nunca concatenar entradas del usuario.", "Manejar valores nulos, duplicados y tipos inesperados."] },
  scripting: { kw: /script|automatiz|archivo|carpeta|renombrar|cron|lote|batch/gi, rol: (l) => `Ingeniero de automatización experto en scripting seguro con ${l}`, ctx: "Script de automatización en un entorno controlado", rest: ["Verificar rutas y permisos antes de escribir o borrar.", "Ofrecer modo de simulación (dry-run) para operaciones destructivas."] },
  pruebas: { kw: /prueba|test|unitaria|cobertura|pytest|jest|mock|qa/gi, rol: (l) => `Ingeniero QA / SDET senior con ${l}`, ctx: "Suite de pruebas automatizadas", rest: ["Cubrir casos felices, de borde y de error.", "Pruebas independientes y deterministas."] },
};
const BY_WORD = [
  { re: /contraseñ|password|clave/i, rest: ["Longitud mínima de 12 caracteres con mayúsculas, minúsculas, números y símbolos.", "Hashing con argon2 o bcrypt; nunca guardar contraseñas en texto plano."] },
  { re: /email|correo/i, rest: ["Validar y normalizar el formato del correo."] },
  { re: /login|sesi[oó]n|token|jwt/i, rest: ["Tokens con expiración corta y comparación en tiempo constante."] },
];
const SECURITY = ["Prohibido incluir credenciales en el código; leerlas de variables de entorno.", "No usar eval, exec ni deserialización insegura.", "Manejo estricto de excepciones sin filtrar datos sensibles."];

export const ROLES: Record<Exclude<RoleId, "auto">, { name: string; emoji: string; greeting: string; prompt: string }> = {
  profesor: { name: "Profesor mentor", emoji: "👨‍🏫", greeting: "Hola, soy tu profesor. Te explicaré cada decisión del código como en clase.", prompt: "Actúa como profesor universitario de desarrollo de software. Explica paso a paso cada decisión, con lenguaje claro para un estudiante de tecnología" },
  revisor: { name: "Revisor de código", emoji: "🔍", greeting: "Soy tu revisor. Señalaré riesgos, malos olores y mejoras antes del merge.", prompt: "Actúa como revisor de código senior que audita calidad, seguridad y mantenibilidad" },
  arquitecto: { name: "Arquitecto de software", emoji: "🏛️", greeting: "Soy arquitecto. Pensaré en capas, escalabilidad y despliegue.", prompt: "Actúa como arquitecto de software que diseña soluciones modulares, escalables y desplegables" },
};

export interface DataSource { id: string; name: string; kind: "csv" | "json" | "api"; fields: string[]; sample: string }
export const DATASETS: DataSource[] = [
  { id: "ventas", name: "ventas.csv", kind: "csv", fields: ["fecha", "producto", "cantidad", "precio_unitario", "ciudad"], sample: "2026-03-01,Teclado,3,85000,Bogotá\n2026-03-02,Mouse,5,42000,Medellín" },
  { id: "estudiantes", name: "estudiantes.json", kind: "json", fields: ["codigo", "programa", "semestre", "promedio"], sample: '[{"codigo":"T001","programa":"Desarrollo de Software","semestre":5,"promedio":4.2}]' },
  { id: "api", name: "API pública: datos.gov.co", kind: "api", fields: ["departamento", "municipio", "valor", "anio"], sample: "GET https://www.datos.gov.co/resource/xxxx.json?$limit=2" },
];

export interface StructureOptions { lang: string; role: RoleId; subject: string; dataset?: DataSource | undefined; asApi: boolean }
export interface Structured { prompt: string; domain: Domain; language: string; ambiguous: boolean; langsFound: string[] }

export function structure(idea: string, o: StructureOptions): Structured {
  const scores = (Object.keys(DOMAINS) as Domain[]).map((k) => [k, (idea.match(DOMAINS[k].kw) || []).length] as const).sort((a, b) => b[1] - a[1]);
  const top = scores[0];
  const domain: Domain = top && top[1] > 0 ? top[0] : "backend";
  const found = Object.keys(LANGS).filter((k) => LANGS[k]!.re.test(idea));
  const lk = o.lang !== "auto" ? o.lang : found[0] ?? DEFAULT_LANG[domain];
  const L = LANGS[lk] ?? LANGS["python"]!;
  const D = DOMAINS[domain];
  const role = o.role === "auto" ? `Actúa como ${D.rol(L.n)}` : `${ROLES[o.role].prompt}, con dominio de ${L.n}`;
  let ctx = `${D.ctx}, dentro de la materia «${o.subject}». Lenguaje objetivo: ${L.n}.`;
  const rest = [...BY_WORD.filter((w) => w.re.test(idea)).flatMap((w) => w.rest), ...D.rest, ...SECURITY];
  const fmt = [`Código ${L.n} comentado (${L.doc}) en un único bloque Markdown.`, `Ejemplos de prueba con ${L.test}.`];
  if (o.dataset) {
    ctx += ` Fuente de datos: ${o.dataset.name} con campos [${o.dataset.fields.join(", ")}]. Muestra:\n${o.dataset.sample}`;
    rest.unshift("Validar el esquema de la fuente de datos antes de procesarla y no exponer datos personales.");
  }
  if (o.asApi) fmt.push("Exponer la lógica como API REST (endpoint, método, JSON de entrada/salida y códigos de estado).");
  if (o.role === "profesor") fmt.push("Al final, una sección «Lo que aprendiste» con 3 conceptos clave.");
  const tarea = idea.trim().replace(/\s+/g, " ").replace(/[.\s]+$/, "");
  const prompt = [
    `[ROL]: ${role}.`, "",
    `[CONTEXTO]: ${ctx}`, "",
    `[TAREA]: Diseña e implementa, sin suposiciones implícitas: «${tarea}».`, "",
    "[RESTRICCIONES]:", ...rest.map((r, i) => `  ${i + 1}. ${r}`), "",
    "[FORMATO DE SALIDA]:", ...fmt.map((f) => `  - ${f}`),
  ].join("\n");
  return { prompt, domain, language: L.n, ambiguous: o.lang === "auto" && found.length > 1, langsFound: found.map((k) => LANGS[k]!.n) };
}

export const PILLARS = [
  { key: "ROL", label: "Rol", color: "pillar-1", hint: "Quién debe ser el modelo." },
  { key: "CONTEXTO", label: "Contexto", color: "pillar-2", hint: "Dónde y para qué se usará." },
  { key: "TAREA", label: "Tarea", color: "pillar-3", hint: "Qué construir, sin suposiciones." },
  { key: "RESTRICCIONES", label: "Restricciones", color: "pillar-4", hint: "Seguridad, librerías, prohibiciones." },
  { key: "FORMATO DE SALIDA", label: "Formato", color: "pillar-5", hint: "Cómo se entrega la respuesta." },
] as const;

/** Estimación de tokens: ~4 caracteres por token en español (referencial). */
export const estimateTokens = (text: string) => Math.ceil(text.length / 4);

export const ENGINES: Record<EngineId, { name: string; model: string; priceIn: number; priceOut: number; strengths: Record<Domain, number>; note: string }> = {
  claude: { name: "Claude", model: "Claude Sonnet 5", priceIn: 3, priceOut: 15, strengths: { backend: 5, frontend: 4, datos: 4, scripting: 4, pruebas: 5 }, note: "Mejor razonamiento sobre código y seguridad." },
  gpt: { name: "GPT", model: "GPT-6.1 Terra", priceIn: 1.25, priceOut: 10, strengths: { backend: 4, frontend: 5, datos: 4, scripting: 5, pruebas: 4 }, note: "Versátil y rápido para interfaces y scripts." },
  gemini: { name: "Gemini", model: "Gemini 3.8 Flash", priceIn: 0.3, priceOut: 2.5, strengths: { backend: 3, frontend: 4, datos: 5, scripting: 4, pruebas: 3 }, note: "El más económico; fuerte con datos y textos largos." },
};

/** Recomienda el motor con mayor afinidad al dominio que aún tenga cupo para la petición. */
export function recommendEngine(domain: Domain, needed: number, used: Record<EngineId, number>, budget: number): EngineId | null {
  const ids = (Object.keys(ENGINES) as EngineId[]).sort((a, b) => ENGINES[b].strengths[domain] - ENGINES[a].strengths[domain] || ENGINES[a].priceIn - ENGINES[b].priceIn);
  return ids.find((id) => budget - used[id] >= needed) ?? null;
}

export const costUSD = (id: EngineId, tin: number, tout: number) => (tin * ENGINES[id].priceIn + tout * ENGINES[id].priceOut) / 1e6;

export interface ReviewItem { pillar: string; ok: boolean; tip: string }
export function reviewPrompt(p: string): ReviewItem[] {
  const has = (k: string) => p.includes(`[${k}]`);
  const rolLine = p.match(/\[ROL\]:(.*)/)?.[1]?.trim() ?? "";
  return [
    { pillar: "Rol", ok: has("ROL") && rolLine.length > 25, tip: has("ROL") ? (rolLine.length > 25 ? "Rol general bien definido." : "Te faltó el rol general: indica especialidad y nivel (p. ej. «profesor de bases de datos»).") : "Te faltó el rol general: ¿quién debe ser el modelo?" },
    { pillar: "Contexto", ok: has("CONTEXTO") && /materia|fuente|aplicaci|m[oó]dulo/i.test(p), tip: "Di dónde se usará el código y con qué datos." },
    { pillar: "Tarea", ok: has("TAREA") && (p.match(/\[TAREA\]:(.*)/)?.[1]?.length ?? 0) > 50, tip: "Describe la tarea con verbo, entrada y salida esperadas." },
    { pillar: "Restricciones", ok: has("RESTRICCIONES") && (p.match(/^\s+\d+\./gm) || []).length >= 3, tip: "Incluye al menos 3 restricciones (seguridad, librerías, estilo)." },
    { pillar: "Formato", ok: has("FORMATO DE SALIDA"), tip: "Indica cómo quieres la respuesta: bloque de código, pruebas, API." },
  ];
}
