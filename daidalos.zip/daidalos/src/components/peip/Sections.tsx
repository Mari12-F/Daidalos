import { useState } from "react";
import { Button } from "@/components/ui/button";

const STAGES = [
  { n: "Planear", d: "Historias de usuario y backlog del sprint (Scrum, 2 semanas).", ai: "Pide al modelo que convierta requisitos en historias con criterios de aceptación." },
  { n: "Versionar", d: "git init, rama main protegida, ramas feature/* y commits convencionales.", ai: "Genera mensajes de commit y .gitignore con un prompt estructurado." },
  { n: "Diseñar", d: "Arquitectura, modelo de datos y contrato de la API.", ai: "Rol arquitecto: propone capas, endpoints y esquema." },
  { n: "Desarrollar", d: "Implementación con prompts de los cinco pilares en Daídalos.", ai: "Rol backend/frontend con restricciones de seguridad obligatorias." },
  { n: "Probar", d: "Pruebas unitarias, de integración y revisión de vulnerabilidades.", ai: "Rol QA: casos felices, de borde y de error." },
  { n: "Revisar", d: "Pull request, revisión de código y merge a main.", ai: "Rol revisor: señala riesgos antes de aprobar." },
  { n: "Desplegar", d: "CI/CD: cada push a main publica una nueva versión.", ai: "Genera el Dockerfile y el pipeline de despliegue." },
  { n: "Monitorear", d: "Logs, métricas, consumo de tokens y feedback de usuarios.", ai: "Analiza errores del log y prioriza el siguiente backlog." },
];

export function Lifecycle() {
  const [done, setDone] = useState<number[]>([]);
  const [lap, setLap] = useState(1);
  const all = done.length === STAGES.length;
  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center gap-3">
        <span className="rounded-full bg-primary/15 px-3 py-1 font-mono text-sm text-primary">Vuelta {lap}</span>
        <span className="text-sm text-muted-foreground">{done.length}/{STAGES.length} etapas completadas</span>
        <Button size="sm" variant="outline" disabled={!all} onClick={() => { setDone([]); setLap(lap + 1); }}>Cerrar ciclo y volver a Planear ↻</Button>
      </div>
      <ol className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        {STAGES.map((s, i) => {
          const on = done.includes(i);
          return (
            <li key={s.n}>
              <button onClick={() => setDone(on ? done.filter((x) => x !== i) : [...done, i])}
                className={`panel h-full w-full p-4 text-left transition hover:-translate-y-0.5 ${on ? "glow" : ""}`}>
                <div className="flex items-center justify-between">
                  <span className="font-mono text-xs text-muted-foreground">{String(i + 1).padStart(2, "0")}</span>
                  <span className={`h-2.5 w-2.5 rounded-full ${on ? "bg-success" : "bg-muted"}`} />
                </div>
                <h4 className="mt-2 font-semibold">{s.n}</h4>
                <p className="mt-1 text-sm text-muted-foreground">{s.d}</p>
                <p className="mt-3 border-t border-border pt-2 text-xs text-accent">IA: {s.ai}</p>
              </button>
            </li>
          );
        })}
      </ol>
      <p className="text-sm text-muted-foreground">Al monitorear, los hallazgos vuelven al backlog: el ciclo se recorre otra vez con una nueva versión (v1.0 → v1.1 → …).</p>
    </div>
  );
}

const STEPS = [
  { t: "Fundamentos", d: "Lógica, un lenguaje (Python o JavaScript), terminal y Git.", w: "Semanas 1–4" },
  { t: "Web básica", d: "HTML, CSS, accesibilidad y JavaScript en el navegador.", w: "Semanas 5–8" },
  { t: "Backend y datos", d: "APIs REST, bases de datos SQL y consumo de datasets públicos.", w: "Semanas 9–12" },
  { t: "IA como copiloto", d: "Ingeniería de prompts con los cinco pilares; revisar siempre lo generado.", w: "Semanas 13–14" },
  { t: "Primer despliegue", d: "Publicar un proyecto propio con CI/CD y variables de entorno.", w: "Semanas 15–16" },
];
export function Training() {
  return (
    <div className="grid gap-6 lg:grid-cols-[1fr_1.2fr]">
      <div className="space-y-3">
        <h3 className="text-xl font-semibold">Primeros pasos como desarrollador web</h3>
        <p className="text-muted-foreground">Daídalos acompaña al desarrollador junior: estructura su idea, la revisa como un mentor y le explica el porqué de cada ajuste. La IA no reemplaza al desarrollador, redefine su papel.</p>
        <div className="panel p-4 text-sm">
          <p className="font-semibold text-primary">Acople en la universidad</p>
          <p className="mt-1 text-muted-foreground">Cada materia (Programación, Bases de datos, Ingeniería de software, Seguridad, Desarrollo web) aporta su contexto y restricciones al prompt. El docente puede fijar un cupo de tokens por curso.</p>
        </div>
      </div>
      <ol className="relative space-y-4 border-l border-border pl-6">
        {STEPS.map((s, i) => (
          <li key={s.t} className="animate-rise" style={{ animationDelay: `${i * 60}ms` }}>
            <span className="absolute -left-[7px] mt-1.5 h-3 w-3 rounded-full bg-primary" />
            <p className="font-mono text-xs text-muted-foreground">{s.w}</p>
            <p className="font-semibold">{s.t}</p>
            <p className="text-sm text-muted-foreground">{s.d}</p>
          </li>
        ))}
      </ol>
    </div>
  );
}

const DEPLOY = [
  ["Lovable Cloud (recomendado)", "Publicación en un clic, servidor seguro para las claves de IA y motores Claude, GPT y Gemini sin gestionar API keys.", "Sustentación y uso por estudiantes"],
  ["Render / Railway", "Servicio web Node.js conectado a GitHub; claves como variables de entorno.", "Versión VS Code del prototipo"],
  ["Servidor de la universidad (Docker)", "El Dockerfile incluido corre en la red institucional; los datos no salen de la universidad.", "Uso por materias a gran escala"],
  ["GitHub Pages", "No sirve: no ejecuta servidor y la clave quedaría expuesta.", "Descartado"],
];
export function Deploy() {
  return (
    <div className="space-y-6">
      <div className="panel glow p-5">
        <p className="text-sm text-muted-foreground">Lugar más adecuado</p>
        <p className="text-xl font-semibold">Publicar en Lovable Cloud y exponer Daídalos como app + API</p>
        <ol className="mt-3 list-decimal space-y-1 pl-5 text-sm text-muted-foreground">
          <li>Versiona el código en GitHub (rama main protegida).</li>
          <li>Publica la app: la interfaz y el servicio de motores quedan en una URL pública.</li>
          <li>El servicio de motores recibe el prompt, revisa el cupo y enruta a Claude → GPT → Gemini.</li>
          <li>Otras apps de la universidad pueden consumir ese mismo servicio como API.</li>
          <li>Cada cambio aprobado se vuelve a publicar: el ciclo de vida se reinicia.</li>
        </ol>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead><tr className="border-b border-border text-left text-muted-foreground"><th className="py-2 pr-4">Opción</th><th className="py-2 pr-4">Cómo funciona</th><th className="py-2">Cuándo</th></tr></thead>
          <tbody>{DEPLOY.map(([a, b, c]) => <tr key={a} className="border-b border-border/60"><td className="py-2 pr-4 font-medium">{a}</td><td className="py-2 pr-4 text-muted-foreground">{b}</td><td className="py-2">{c}</td></tr>)}</tbody>
        </table>
      </div>
    </div>
  );
}
