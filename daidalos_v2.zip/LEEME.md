# Daídalos

Estructurador de prompts de cinco pilares, estimación de tokens y mentoría de desarrollo de software.

## Ejecutar en el computador

Requisitos: Node.js 22.12 o superior y npm.

Extrae el ZIP y abre una terminal en la carpeta que contiene `package.json`:

```sh
npm install
npm run dev -- --port 8080
```

Abre `http://localhost:8080`. No abras los archivos fuente haciendo doble clic.

## Compilar para un servidor Node.js

```sh
npm run build:local
npm run start:local
```

Abre `http://localhost:3000`.

TanStack Start genera el HTML desde `src/routes/__root.tsx` y `src/routes/index.tsx`: no necesita un `index.html` como entrada. La compilación local genera el servidor en `.output/server/index.mjs` y los archivos CSS y JavaScript en `.output/public`.

## Versión HTML

Para volver a generar la versión HTML:

```sh
npm run build:html
```

El resultado está en `dist/client/index.html` y `dist/client/assets`.

La entrega HTML contiene `index.html` y la carpeta `assets`. Conserva ambos juntos y sirve la carpeta mediante HTTP, por ejemplo:

```sh
python -m http.server 8000
```

Abre `http://localhost:8000`. La estructuración, la estimación de tokens, la revisión local y la simulación funcionan sin un servicio de generación. Generar código y pedir mentoría con modelos requieren el servicio de IA del servidor y credenciales autorizadas; el HTML por sí solo no los proporciona. No contiene claves privadas ni respuestas simuladas.

## Pruebas

```sh
npm test
```
