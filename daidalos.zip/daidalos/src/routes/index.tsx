import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Slider } from "@/components/ui/slider";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { DATASETS, ENGINES, LANGS, PILLARS, ROLES, costUSD, estimateTokens, recommendEngine, reviewPrompt, structure, type EngineId, type RoleId, type Structured } from "@/lib/peip";
import { generateWithEngines } from "@/lib/generate.functions";
import { Deploy, Lifecycle, Training } from "@/components/peip/Sections";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Daídalos · Estructurador de prompts con IA" },
      { name: "description", content: "Convierte tu idea en un prompt de cinco pilares, estima tokens y genera código con Claude, GPT o Gemini." },
      { property: "og:title", content: "Daídalos · Estructurador de prompts con IA" },
      { property: "og:description", content: "Prompts estructurados, cambio de motor y mentoría para desarrolladores." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

const EXAMPLE = "Necesito una función para validar contraseñas de usuarios en mi sistema en Python que sea segura.";
const SUBJECTS = ["Programación", "Bases de datos", "Ingeniería de software", "Seguridad informática", "Desarrollo web"];
const IDS: EngineId[] = ["claude", "gpt", "gemini"];
type LogEntry = { mode: string; engine?: EngineId | undefined; route: { engine: string; status: string; detail: string }[]; tokens: number };

function Index() {
  const gen = useServerFn(generateWithEngines);
  const [idea, setIdea] = useState("");
  const [lang, setLang] = useState("auto");
  const [role, setRole] = useState<RoleId>("profesor");
  const [subject, setSubject] = useState(SUBJECTS[0]!);
  const [ds, setDs] = useState("none");
  const [asApi, setAsApi] = useState(false);
  const [res, setRes] = useState<Structured | null>(null);
  const [prompt, setPrompt] = useState("");
  const [output, setOutput] = useState("");
  const [busy, setBusy] = useState<"" | "code" | "mentor">("");
  const [mentor, setMentor] = useState("");
  const [pref, setPref] = useState<EngineId | "auto">("auto");
  const [budget, setBudget] = useState(20000);
  const [used, setUsed] = useState<Record<EngineId, number>>({ claude: 0, gpt: 0, gemini: 0 });
  const [simGens, setSimGens] = useState(0);
  const [log, setLog] = useState<LogEntry[]>([]);

  const dataset = DATASETS.find((d) => d.id === ds);
  const inTok = estimateTokens(prompt);
  const outTok = Math.max(600, Math.round(inTok * 2.5));
  const need = inTok + outTok;
  const domain = res?.domain ?? "backend";
  const reco = recommendEngine(domain, need, used, budget);
  const review = useMemo(() => reviewPrompt(prompt), [prompt]);
  const order: EngineId[] = useMemo(() => {
    const first = pref === "auto" ? reco ?? "claude" : pref;
    return [first, ...IDS.filter((i) => i !== first)];
  }, [pref, reco]);

  const doStructure = (text = idea) => {
    if (!text.trim()) { toast.error("Escribe primero tu idea."); return; }
    const r = structure(text, { lang, role, subject, dataset, asApi });
    setRes(r); setPrompt(r.prompt);
  };

  const run = async (mode: "code" | "mentor") => {
    setBusy(mode);
    try {
      const exhausted = IDS.filter((i) => budget - used[i] < need);
      const r = await gen({ data: { prompt, mode, order, exhausted } });
      const tokens = r.ok ? r.input + r.output : 0;
      setLog((l) => [{ mode: mode === "code" ? "Código" : "Mentoría", engine: r.ok ? r.engine : undefined, route: r.route, tokens }, ...l].slice(0, 8));
      if (!r.ok) { toast.error(r.error); return; }
      setUsed((u) => ({ ...u, [r.engine]: u[r.engine] + tokens }));
      if (r.engine !== order[0]) toast.info(`Cambio de motor: ${ENGINES[order[0]!].name} → ${ENGINES[r.engine].name}`);
      if (mode === "code") setOutput(r.text); else setMentor(r.text);
    } catch {
      toast.error("No se pudo contactar el servicio de motores.");
    } finally { setBusy(""); }
  };

  // Simulación: cada generación consume `need` tokens del motor activo hasta agotar su cupo.
  const sim = useMemo(() => {
    const u: Record<EngineId, number> = { claude: 0, gpt: 0, gemini: 0 };
    const switches: string[] = [];
    let last: EngineId | null = null;
    for (let g = 1; g <= simGens; g++) {
      const e = recommendEngine(domain, need, u, budget);
      if (!e) { switches.push(`Generación ${g}: todos los motores sin cupo`); break; }
      if (last && e !== last) switches.push(`Generación ${g}: ${ENGINES[last].name} → ${ENGINES[e].name}`);
      u[e] += need; last = e;
    }
    return { u, switches };
  }, [simGens, domain, need, budget]);
  const maxGens = Math.floor(budget / need) * 3;

  return (
    <div className="mx-auto max-w-7xl px-4 pb-16 pt-8 sm:px-6">
      <header className="animate-rise">
        <div className="flex flex-wrap items-center gap-2 font-mono text-xs text-muted-foreground">
          <span className="rounded-full border border-border px-3 py-1">Daídalos</span>
          <span className="rounded-full border border-primary/50 px-3 py-1 text-primary">v3.0</span>
        </div>
        <h1 className="mt-4 max-w-3xl text-4xl font-bold leading-tight tracking-tight sm:text-5xl">
          De tu idea a un prompt <span className="text-primary">preciso</span>, en cinco pilares.
        </h1>
        <p className="mt-3 max-w-2xl text-muted-foreground">Escribe como te salga. Daídalos lo convierte en Rol, Contexto, Tarea, Restricciones y Formato, calcula los tokens, elige el motor de IA y te acompaña como mentor.</p>
        <div className="mt-5 flex flex-wrap gap-2">
          {PILLARS.map((p) => {
            const on = prompt.includes(`[${p.key}]`);
            return <span key={p.key} title={p.hint} className={`rounded-full border px-3 py-1 text-sm transition ${on ? "opacity-100" : "opacity-35"}`} style={{ borderColor: `var(--${p.color})`, color: `var(--${p.color})` }}>{p.label}</span>;
          })}
        </div>
      </header>

      <Tabs defaultValue="estructurar" className="mt-8">
        <TabsList className="flex h-auto flex-wrap justify-start gap-1 bg-card p-1">
          {([["estructurar", "1 · Estructurar"], ["motor", "2 · Tokens y motor"], ["mentor", "3 · Mentor"], ["ciclo", "4 · Ciclo de vida"], ["formacion", "5 · Formación"], ["despliegue", "6 · Despliegue"]] as const).map(([v, l]) => (
            <TabsTrigger key={v} value={v} className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">{l}</TabsTrigger>
          ))}
        </TabsList>

        <TabsContent value="estructurar" className="mt-5">
          <div className="grid gap-4 lg:grid-cols-[0.9fr_1.1fr_1.1fr]">
            <section className="panel space-y-4 p-5">
              <h2 className="font-semibold">Tu idea</h2>
              <Textarea value={idea} onChange={(e) => setIdea(e.target.value)} placeholder={EXAMPLE} className="min-h-28 bg-background" />
              <Field label="Rol del modelo">
                <Select value={role} onValueChange={(v) => setRole(v as RoleId)}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent><SelectItem value="auto">Según el dominio</SelectItem>{Object.entries(ROLES).map(([k, r]) => <SelectItem key={k} value={k}>{r.emoji} {r.name}</SelectItem>)}</SelectContent>
                </Select>
              </Field>
              {role !== "auto" && (
                <div className="flex gap-3 rounded-lg border border-pillar-1/40 bg-pillar-1/10 p-3 animate-rise">
                  <span className="text-3xl" aria-hidden>{ROLES[role].emoji}</span>
                  <p className="text-sm"><b className="text-pillar-1">{ROLES[role].name}:</b> “{ROLES[role].greeting}”</p>
                </div>
              )}
              <div className="grid grid-cols-2 gap-3">
                <Field label="Lenguaje">
                  <Select value={lang} onValueChange={setLang}><SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent><SelectItem value="auto">Detectar</SelectItem>{Object.entries(LANGS).map(([k, l]) => <SelectItem key={k} value={k}>{l.n}</SelectItem>)}</SelectContent></Select>
                </Field>
                <Field label="Materia">
                  <Select value={subject} onValueChange={setSubject}><SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>{SUBJECTS.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent></Select>
                </Field>
              </div>
              <Field label="Carga de ejemplo (dataset o API)">
                <Select value={ds} onValueChange={setDs}><SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent><SelectItem value="none">Sin datos</SelectItem>{DATASETS.map((d) => <SelectItem key={d.id} value={d.id}>{d.name}</SelectItem>)}</SelectContent></Select>
              </Field>
              {dataset && <pre className="overflow-x-auto rounded-md bg-code p-2 font-mono text-xs text-muted-foreground">{dataset.fields.join(" | ")}{"\n"}{dataset.sample}</pre>}
              <label className="flex items-center justify-between gap-3 text-sm">Entregar como API REST consumible <Switch checked={asApi} onCheckedChange={setAsApi} /></label>
              <div className="flex gap-2">
                <Button onClick={() => doStructure()}>Estructurar prompt</Button>
                <Button variant="outline" onClick={() => { setIdea(EXAMPLE); doStructure(EXAMPLE); }}>Ejemplo</Button>
              </div>
            </section>

            <section className="panel flex flex-col gap-3 p-5">
              <div className="flex items-center justify-between"><h2 className="font-semibold">Prompt estructurado</h2>
                {res && <span className="font-mono text-xs text-muted-foreground">{res.domain} · {res.language}</span>}</div>
              {res?.ambiguous && <p className="text-sm text-pillar-3">Mencionas varios lenguajes ({res.langsFound.join(", ")}). Elige uno en el selector.</p>}
              <Textarea value={prompt} onChange={(e) => setPrompt(e.target.value)} spellCheck={false} placeholder="Aquí aparecerá tu prompt; puedes editarlo." className="min-h-[360px] flex-1 bg-code font-mono text-xs leading-relaxed" />
              <div className="grid grid-cols-3 gap-2 text-center">
                <Stat k="Entrada" v={`~${inTok}`} /><Stat k="Salida est." v={`~${prompt ? outTok : 0}`} /><Stat k="Motor sugerido" v={prompt ? (reco ? ENGINES[reco].name : "Sin cupo") : "—"} />
              </div>
              <Button disabled={!prompt || !!busy} onClick={() => run("code")}>{busy === "code" ? "Generando…" : `Generar código con ${ENGINES[order[0]!].name}`}</Button>
            </section>

            <section className="panel flex min-w-0 flex-col gap-3 p-5">
              <h2 className="font-semibold">Código generado</h2>
              {output ? <pre className="max-h-[520px] flex-1 overflow-auto whitespace-pre-wrap rounded-md bg-code p-3 font-mono text-xs">{output}</pre>
                : <div className="grid flex-1 place-items-center rounded-md border border-dashed border-border p-6 text-center text-sm text-muted-foreground">Estructura tu idea y pulsa «Generar código».</div>}
              {output && <Button variant="outline" onClick={() => { void navigator.clipboard.writeText(output); toast.success("Copiado"); }}>Copiar</Button>}
            </section>
          </div>
        </TabsContent>

        <TabsContent value="motor" className="mt-5 space-y-5">
          <div className="grid gap-4 md:grid-cols-3">
            {IDS.map((id) => {
              const e = ENGINES[id]; const pct = Math.min(100, (used[id] / budget) * 100);
              return (
                <div key={id} className={`panel p-5 ${reco === id && prompt ? "glow" : ""}`}>
                  <div className="flex items-baseline justify-between"><h3 className="text-lg font-semibold">{e.name}</h3><span className="font-mono text-xs text-muted-foreground">{e.model}</span></div>
                  <p className="mt-1 text-sm text-muted-foreground">{e.note}</p>
                  <p className="mt-3 text-sm">Afinidad con «{domain}»: <b className="text-primary">{"★".repeat(e.strengths[domain])}{"☆".repeat(5 - e.strengths[domain])}</b></p>
                  <p className="text-sm">Costo de esta petición: <b>${costUSD(id, inTok, outTok).toFixed(4)}</b> USD</p>
                  <div className="mt-3 h-2 overflow-hidden rounded-full bg-muted"><div className="h-full bg-primary transition-all" style={{ width: `${pct}%` }} /></div>
                  <p className="mt-1 font-mono text-xs text-muted-foreground">{used[id].toLocaleString()} / {budget.toLocaleString()} tokens · alcanza para ~{Math.max(0, Math.floor((budget - used[id]) / need))} peticiones</p>
                </div>
              );
            })}
          </div>
          <div className="panel grid gap-6 p-5 lg:grid-cols-2">
            <div className="space-y-4">
              <Field label="Motor preferido">
                <Select value={pref} onValueChange={(v) => setPref(v as EngineId | "auto")}><SelectTrigger className="w-60"><SelectValue /></SelectTrigger>
                  <SelectContent><SelectItem value="auto">Automático (afinidad + cupo)</SelectItem>{IDS.map((i) => <SelectItem key={i} value={i}>{ENGINES[i].name}</SelectItem>)}</SelectContent></Select>
              </Field>
              <Field label={`Cupo por motor: ${budget.toLocaleString()} tokens`}><Slider min={2000} max={100000} step={1000} value={[budget]} onValueChange={(v) => setBudget(v[0] ?? budget)} /></Field>
              <p className="text-sm text-muted-foreground">Orden de enrutamiento: <b className="text-foreground">{order.map((o) => ENGINES[o].name).join(" → ")}</b>. Si un motor no tiene cupo o falla, la petición pasa al siguiente automáticamente.</p>
              <Button variant="outline" size="sm" onClick={() => setUsed((u) => ({ ...u, [order[0]!]: budget }))}>Simular cupo agotado en {ENGINES[order[0]!].name}</Button>
              <Button variant="ghost" size="sm" onClick={() => setUsed({ claude: 0, gpt: 0, gemini: 0 })}>Reiniciar cupos</Button>
            </div>
            <div className="space-y-3">
              <h3 className="font-semibold">¿Me alcanzan los tokens? Simulación</h3>
              <Field label={`Generaciones: ${simGens} (≈${need} tokens c/u)`}><Slider min={0} max={Math.max(3, maxGens + 2)} value={[simGens]} onValueChange={(v) => setSimGens(v[0] ?? 0)} /></Field>
              {IDS.map((id) => <div key={id} className="flex items-center gap-2 text-sm"><span className="w-16">{ENGINES[id].name}</span><div className="h-2 flex-1 overflow-hidden rounded-full bg-muted"><div className="h-full bg-accent transition-all" style={{ width: `${Math.min(100, (sim.u[id] / budget) * 100)}%` }} /></div></div>)}
              <ul className="space-y-1 font-mono text-xs text-pillar-3">{sim.switches.length ? sim.switches.map((s) => <li key={s}>↪ {s}</li>) : <li className="text-muted-foreground">Sin cambios de motor todavía.</li>}</ul>
            </div>
          </div>
          <div className="panel p-5">
            <h3 className="font-semibold">Registro real de rutas</h3>
            {log.length === 0 ? <p className="mt-2 text-sm text-muted-foreground">Aún no hay generaciones.</p> :
              <ul className="mt-2 space-y-2 text-sm">{log.map((l, i) => <li key={i} className="font-mono text-xs">{l.mode}: {l.route.map((r) => `${ENGINES[r.engine as EngineId].name} ${r.status === "ok" ? "✓" : r.status === "skipped" ? "⤳ omitido" : "✗"} (${r.detail})`).join("  →  ")}</li>)}</ul>}
          </div>
        </TabsContent>

        <TabsContent value="mentor" className="mt-5">
          <div className="grid gap-4 lg:grid-cols-2">
            <div className="panel space-y-3 p-5">
              <div className="flex items-center gap-3"><span className="text-4xl">👨‍🏫</span><div><h3 className="font-semibold">Revisión del mentor</h3><p className="text-sm text-muted-foreground">Local e instantánea, no gasta tokens.</p></div></div>
              {!prompt ? <p className="text-sm text-muted-foreground">Estructura un prompt primero (o escribe uno propio en la pestaña 1).</p> :
                <ul className="space-y-2">{review.map((r) => <li key={r.pillar} className="flex gap-3 rounded-md border border-border p-3 text-sm"><span className={r.ok ? "text-success" : "text-destructive"}>{r.ok ? "✓" : "!"}</span><span><b>{r.pillar}:</b> {r.tip}</span></li>)}</ul>}
              <p className="text-sm">Puntaje: <b className="text-primary">{review.filter((r) => r.ok).length}/5 pilares</b></p>
            </div>
            <div className="panel flex flex-col gap-3 p-5">
              <h3 className="font-semibold">Mentoría con IA</h3>
              <p className="text-sm text-muted-foreground">El modelo analiza tu prompt, te propone ajustes y una versión mejorada. Consume ~{need} tokens.</p>
              <Button disabled={!prompt || !!busy} onClick={() => run("mentor")}>{busy === "mentor" ? "Analizando…" : "Pedir mentoría"}</Button>
              {mentor && <pre className="max-h-[480px] overflow-auto whitespace-pre-wrap rounded-md bg-code p-3 text-sm">{mentor}</pre>}
            </div>
          </div>
        </TabsContent>

        <TabsContent value="ciclo" className="mt-5"><Lifecycle /></TabsContent>
        <TabsContent value="formacion" className="mt-5"><Training /></TabsContent>
        <TabsContent value="despliegue" className="mt-5"><Deploy /></TabsContent>
      </Tabs>

      <footer className="mt-12 border-t border-border pt-6 text-sm text-muted-foreground">Daídalos mejora la formulación de la petición, pero no sustituye la revisión humana del código..</footer>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return <div className="space-y-1.5"><p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">{label}</p>{children}</div>;
}
function Stat({ k, v }: { k: string; v: string }) {
  return <div className="rounded-md border border-border p-2"><p className="text-[10px] uppercase tracking-wide text-muted-foreground">{k}</p><p className="font-mono text-sm font-semibold">{v}</p></div>;
}
