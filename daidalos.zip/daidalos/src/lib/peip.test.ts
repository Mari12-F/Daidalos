import { describe, it, expect } from "vitest";
import { recommendEngine, estimateTokens, structure, reviewPrompt } from "./peip";

describe("PEIP", () => {
  it("estima ~4 caracteres por token", () => expect(estimateTokens("a".repeat(400))).toBe(100));
  it("cambia de motor cuando el preferido no tiene cupo", () => {
    expect(recommendEngine("backend", 1000, { claude: 0, gpt: 0, gemini: 0 }, 20000)).toBe("claude");
    expect(recommendEngine("backend", 1000, { claude: 19500, gpt: 0, gemini: 0 }, 20000)).toBe("gpt");
    expect(recommendEngine("backend", 1000, { claude: 20000, gpt: 20000, gemini: 20000 }, 20000)).toBeNull();
  });
  it("genera los cinco pilares", () => {
    const r = structure("función en Python para validar contraseñas", { lang: "auto", role: "profesor", subject: "Programación", asApi: false });
    expect(reviewPrompt(r.prompt).every((i) => i.ok)).toBe(true);
  });
  it("detecta falta de rol general", () => expect(reviewPrompt("[TAREA]: algo")[0]?.ok).toBe(false));
});
