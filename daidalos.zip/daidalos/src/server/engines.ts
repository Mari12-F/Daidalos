import { generateChatCompletion, generateMessage } from "@lovable.dev/ai-gateway";

export type EngineId = "claude" | "gpt" | "gemini";
export interface EngineResult { text: string; input: number; output: number }

export const ENGINE_MODELS: Record<EngineId, string> = {
  claude: "anthropic/claude-sonnet-5",
  gpt: "openai/gpt-6.1-terra",
  gemini: "google/gemini-3.8-flash",
};

export async function callEngine(id: EngineId, system: string, prompt: string): Promise<EngineResult> {
  if (id === "claude") {
    const r = await generateMessage({
      model: "anthropic/claude-sonnet-5",
      max_tokens: 4000,
      system,
      messages: [{ role: "user", content: prompt }],
    });
    const text = r.content.map((b) => (b.type === "text" ? b.text : "")).join("\n");
    return { text, input: r.usage.input_tokens, output: r.usage.output_tokens };
  }
  const messages = [
    { role: "system" as const, content: system },
    { role: "user" as const, content: prompt },
  ];
  const r =
    id === "gpt"
      ? await generateChatCompletion({ model: "openai/gpt-6.1-terra", messages })
      : await generateChatCompletion({ model: "google/gemini-3.8-flash", messages });
  const c = r.choices[0]?.message?.content;
  return {
    text: typeof c === "string" ? c : "",
    input: r.usage?.prompt_tokens ?? 0,
    output: r.usage?.completion_tokens ?? 0,
  };
}
